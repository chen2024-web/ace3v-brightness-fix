# Brightness Fix For Ace3V
Simple Magisk module to fix blackout issue on OnePlus Ace 3V OxygenOS Port with lowest screen brightness
